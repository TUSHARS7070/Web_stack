document.addEventListener("DOMContentLoaded", function () {
  const registrationForm = document.getElementById("registration-form");

  registrationForm.addEventListener("submit", function (event) {
    event.preventDefault();
    const fullName = document.getElementById("full-name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const dob = document.getElementById("dob").value;

    if (
      !validateFullName(fullName) ||
      !validateEmail(email) ||
      !validatePassword(password) ||
      !validateConfirmPassword(password, confirmPassword) ||
      !validateDateOfBirth(dob)
    ) {
      alert("Please fix the errors in the form before submitting.");
      return;
    }

    // Form is valid; you can submit it here if needed
    alert("Registration successful!");
  });

  function validateFullName(fullName) {
    if (fullName.length < 8) {
      alert("Full Name must be at least 8 characters long.");
      return false;
    }
    return true;
  }

  function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailPattern.test(email)) {
      alert("Invalid email format.");
      return false;
    }
    return true;
  }

  function validatePassword(password) {
    if (password.length < 8) {
      alert("Password must be at least 8 characters long.");
      return false;
    }
    return true;
  }

  function validateConfirmPassword(password, confirmPassword) {
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return false;
    }
    return true;
  }

  function validateDateOfBirth(dob) {
    const today = new Date();
    const selectedDate = new Date(dob);

    if (selectedDate >= today) {
      alert("Invalid Date of Birth.");
      return false;
    }
    return true;
  }
});
