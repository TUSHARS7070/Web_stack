from lxml import etree

def validate_xml(xml_file, xsd_file):
    try:
        # Load the XML and XSD files
        xml_doc = etree.parse(xml_file)
        xsd_doc = etree.parse(xsd_file)

        # Create an XML schema validator
        schema = etree.XMLSchema(xsd_doc)

        # Validate the XML against the XSD
        is_valid = schema.validate(xml_doc)

        if is_valid:
            print("Validation successful. The XML is valid against the XSD.")
        else:
            print("Validation failed. The XML is not valid against the XSD.")
            print("Validation errors:")
            for error in schema.error_log:
                print(error)

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    xml_file = "canine_data.xml"  # Replace with the path to your XML file
    xsd_file = "canine_details.xsd"  # Replace with the path to your XSD file

    validate_xml(xml_file, xsd_file)
