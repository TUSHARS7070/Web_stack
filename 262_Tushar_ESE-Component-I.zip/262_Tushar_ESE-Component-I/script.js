document.addEventListener("DOMContentLoaded", () => {
    const fetchButton = document.getElementById("fetchButton");
    const dogImageContainer = document.getElementById("dogImageContainer");

    fetchButton.addEventListener("click", () => {
        fetchRandomDogImage();
    });

    function fetchRandomDogImage() {
        fetch("https://dog.ceo/api/breeds/image/random")
            .then((response) => response.json())
            .then((data) => {
                if (data.status === "success") {
                    displayDogImage(data.message);
                } else {
                    alert("Failed to fetch dog image.");
                }
            })
            .catch((error) => {
                console.error("Error fetching dog image:", error);
            });
    }

    function displayDogImage(imageUrl) {
        const img = document.createElement("img");
        img.src = imageUrl;
        img.alt = "Random Dog Image";
        dogImageContainer.innerHTML = "";
        dogImageContainer.appendChild(img);
    }
});
