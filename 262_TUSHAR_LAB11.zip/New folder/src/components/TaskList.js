import React from "react";
import "./TaskList.css";
const TaskList = ({ tasks, onDelete, onEdit }) => {
  return (
    <div>
      <ul className="todo-list">
        {tasks.map((task, index) => (
          <li key={index} className="todo-item">
            <div className="task-details">
              <strong className="task-name">{task.name}</strong>
              {task.description && (
                <p className="todo-description">{task.description}</p>
              )}
            </div>
            <div className="task-buttons">
              <button onClick={() => onEdit(index)} className="edit-button">
                Edit
              </button>
              <button onClick={() => onDelete(index)} className="delete-button">
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
